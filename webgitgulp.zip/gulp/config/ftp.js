export let configFTP = {
	host: '', //Адрес сервера
	user: '', //Имя пользователя
	password: '', //Пароль
	parallel: 5, //Одновременные потоки
}
